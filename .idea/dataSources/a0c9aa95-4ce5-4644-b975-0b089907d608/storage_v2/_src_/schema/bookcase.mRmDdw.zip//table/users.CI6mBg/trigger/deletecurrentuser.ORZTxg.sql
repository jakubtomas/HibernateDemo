create definer = root@localhost trigger DeleteCurrentUser
    before delete
    on users
    for each row
BEGIN 
INSERT INTO archive_users(id, password,email,active_account,hash) 
VALUES(OLD.id,OLD.password, OLD.email, OLD.active_account, OLD.hash); 
END;

